import React, { Component } from "react";
import styled, { css } from "styled-components";
import IntegrationLogicOnClickTaskCondition from "../components/IntegrationLogicOnClickTaskCondition";

function Untitled(props) {
  return (
    <Container>
      <IntegrationLogicOnClickTaskCondition
        style={{
          width: 168,
          height: 321,
          alignSelf: "center"
        }}
      ></IntegrationLogicOnClickTaskCondition>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  height: 100vh;
  width: 100vw;
`;

export default Untitled;
