import React, { Component } from "react";
import styled, { css } from "styled-components";
import TaskNotificationError from "../components/TaskNotificationError";
import TaskNotificationInfo from "../components/TaskNotificationInfo";
import TaskNotificationSuccess from "../components/TaskNotificationSuccess";

function Untitled(props) {
  return (
    <>
      <TaskNotificationError
        style={{
          width: 416,
          height: 106,
          marginTop: 414,
          marginLeft: 92
        }}
      ></TaskNotificationError>
      <TaskNotificationInfo
        style={{
          width: 416,
          height: 106,
          marginTop: -242,
          alignSelf: "center"
        }}
      ></TaskNotificationInfo>
      <TaskNotificationSuccess
        style={{
          width: 416,
          height: 106,
          marginTop: -243,
          marginLeft: 92
        }}
      ></TaskNotificationSuccess>
    </>
  );
}

export default Untitled;
