import React, { Component } from "react";
import styled, { css } from "styled-components";

function TaskNotificationInfo(props) {
  return (
    <Root {...props}>
      <Rect4>
        <Rect>
          <Rectangle3Row>
            <Rectangle3></Rectangle3>
            <IconInfoIncon>
              <svg
                viewBox="-0 -0 5.300910029053689 29.21112016010284"
                style={{
                  width: 5,
                  height: 29,
                  backgroundColor: "transparent",
                  borderColor: "transparent",
                  marginTop: 17,
                  marginLeft: 28
                }}
              >
                <path
                  strokeWidth={0}
                  fill="rgba(61,111,197,1)"
                  fillOpacity={1}
                  strokeOpacity={1}
                  d="M5.30 10.66 L5.30 25.99 C5.30 25.99 5.05 27.85 4.55 28.39 C4.04 28.94 3.40 29.21 2.62 29.21 C1.85 29.21 1.21 28.93 0.73 28.38 C0.25 27.82 0.00 25.99 0.00 25.99 L0.00 10.82 C0.00 10.82 0.25 8.98 0.73 8.45 C1.21 7.92 1.85 7.65 2.62 7.65 C3.40 7.65 4.04 7.92 4.55 8.45 M2.68 5.18 C1.94 5.18 1.31 4.96 0.79 4.50 C0.26 4.05 0.00 3.41 0.00 2.58 C0.00 1.83 0.27 1.21 0.80 0.73 C1.34 0.24 1.97 0.00 2.68 0.00 C3.37 0.00 3.98 0.22 4.50 0.66 C5.03 1.10 5.30 1.74 5.30 2.58 C5.30 3.40 5.04 4.04 4.53 4.49 "
                ></path>
              </svg>
            </IconInfoIncon>
            <InfoMessageHereRowColumn>
              <InfoMessageHereRow>
                <InfoMessageHere>INFO MESSAGE HERE</InfoMessageHere>
                <IconRespMenuCloseRespMenu1>
                  <Group31Stack>
                    <Group31>
                      <Clip21Stack>
                        <svg
                          viewBox="-0 -0 14.67353887549998 14.67269887556435"
                          style={{
                            top: 0,
                            left: 0,
                            width: 15,
                            height: 15,
                            backgroundColor: "transparent",
                            position: "absolute",
                            borderColor: "transparent"
                          }}
                        >
                          <path
                            strokeWidth={0}
                            fill="transparent"
                            fillOpacity={1}
                            strokeOpacity={1}
                            d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                          ></path>
                        </svg>
                        <svg
                          viewBox="-0 -0 14.67353887549998 14.67269887556435"
                          style={{
                            top: 0,
                            left: 0,
                            width: 15,
                            height: 15,
                            backgroundColor: "transparent",
                            position: "absolute",
                            borderColor: "transparent"
                          }}
                        >
                          <defs>
                            <mask
                              id="TlMKzJ"
                              x={0}
                              y={0}
                              width={14}
                              height={14}
                            >
                              <path
                                d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                                fill="white"
                              />
                            </mask>
                          </defs>
                          <path
                            strokeWidth={0}
                            fill="rgba(242,243,246,1)"
                            fillOpacity={1}
                            strokeOpacity={1}
                            d="M0.25 14.43 C-0.08 14.10 -0.08 13.57 0.25 13.24 L13.24 0.25 C13.57 -0.08 14.10 -0.08 14.43 0.25 C14.76 0.57 14.76 1.11 14.43 1.43 L1.43 14.43 C1.27 14.59 1.05 14.67 0.84 14.67 C0.63 14.67 0.41 14.59 0.25 14.43 Z"
                            mask="url(#TlMKzJ)"
                          ></path>
                        </svg>
                      </Clip21Stack>
                    </Group31>
                    <Group61>
                      <Clip51Stack>
                        <svg
                          viewBox="-0 -0 14.6737068754871 14.67269887556435"
                          style={{
                            top: 0,
                            left: 0,
                            width: 15,
                            height: 15,
                            backgroundColor: "transparent",
                            position: "absolute",
                            borderColor: "transparent"
                          }}
                        >
                          <path
                            strokeWidth={0}
                            fill="transparent"
                            fillOpacity={1}
                            strokeOpacity={1}
                            d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                          ></path>
                        </svg>
                        <svg
                          viewBox="-0 -0 14.6737068754871 14.67269887556435"
                          style={{
                            top: 0,
                            left: 0,
                            width: 15,
                            height: 15,
                            backgroundColor: "transparent",
                            position: "absolute",
                            borderColor: "transparent"
                          }}
                        >
                          <defs>
                            <mask
                              id="NJRSdB"
                              x={0}
                              y={0}
                              width={14}
                              height={14}
                            >
                              <path
                                d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                                fill="white"
                              />
                            </mask>
                          </defs>
                          <path
                            strokeWidth={0}
                            fill="rgba(242,243,246,1)"
                            fillOpacity={1}
                            strokeOpacity={1}
                            d="M13.24 14.43 L0.25 1.43 C-0.08 1.11 -0.08 0.57 0.25 0.25 C0.57 -0.08 1.11 -0.08 1.43 0.25 L14.43 13.24 C14.76 13.57 14.76 14.10 14.43 14.43 C14.26 14.59 14.05 14.67 13.83 14.67 C13.62 14.67 13.40 14.59 13.24 14.43 Z"
                            mask="url(#NJRSdB)"
                          ></path>
                        </svg>
                      </Clip51Stack>
                    </Group61>
                  </Group31Stack>
                </IconRespMenuCloseRespMenu1>
              </InfoMessageHereRow>
              <DescriptionOfInfo>
                Description of info message here. this{"\n"}notification is
                displayed 5 seconds, disapears automatically {"\n"}if user
                doesn’t click on close
              </DescriptionOfInfo>
            </InfoMessageHereRowColumn>
          </Rectangle3Row>
        </Rect>
      </Rect4>
    </Root>
  );
}

const Root = styled.div`
  display: flex;
  flex-direction: column;
`;

const Rect4 = styled.div`
  width: 416px;
  height: 106px;
  background-color: rgba(255,255,255,1);
  flex-direction: column;
  display: flex;
`;

const Rect = styled.div`
  width: 416px;
  height: 106px;
  opacity: 1;
  flex-direction: column;
  display: flex;
`;

const Rectangle3 = styled.div`
  width: 16px;
  height: 105px;
  background-color: rgba(61,111,197,1);
  opacity: 1;
`;

const IconInfoIncon = styled.div`
  width: 62px;
  height: 63px;
  opacity: 0.3;
  flex-direction: column;
  display: flex;
  margin-left: 14px;
  margin-top: 22px;
`;

const InfoMessageHere = styled.span`
  font-family: Raleway;
  background-color: transparent;
  color: rgba(61,111,197,1);
  opacity: 1;
  font-size: 18px;
  font-weight: 700;
  font-style: normal;
  letter-spacing: 0.45px;
  margin-top: 14px;
`;

const IconRespMenuCloseRespMenu1 = styled.div`
  width: 15px;
  height: 16px;
  opacity: 1;
  flex-direction: column;
  display: flex;
  margin-left: 82px;
`;

const Group31 = styled.div`
  top: 0px;
  left: 0px;
  width: 15px;
  height: 15px;
  position: absolute;
  opacity: 1;
  flex-direction: column;
  display: flex;
`;

const Clip21Stack = styled.div`
  width: 15px;
  height: 15px;
  position: relative;
`;

const Group61 = styled.div`
  top: 0px;
  left: 0px;
  width: 15px;
  height: 15px;
  position: absolute;
  opacity: 1;
  flex-direction: column;
  display: flex;
`;

const Clip51Stack = styled.div`
  width: 15px;
  height: 15px;
  position: relative;
`;

const Group31Stack = styled.div`
  width: 15px;
  height: 15px;
  position: relative;
`;

const InfoMessageHereRow = styled.div`
  height: 32px;
  flex-direction: row;
  display: flex;
  margin-right: 8px;
`;

const DescriptionOfInfo = styled.span`
  font-family: Raleway;
  background-color: transparent;
  color: rgba(216,216,216,1);
  opacity: 1;
  font-size: 10px;
  font-weight: 400;
  font-style: normal;
  letter-spacing: 0.25px;
  margin-top: 7px;
  margin-left: 2px;
`;

const InfoMessageHereRowColumn = styled.div`
  width: 294px;
  flex-direction: column;
  display: flex;
  margin-left: 25px;
  margin-top: 10px;
  margin-bottom: 26px;
`;

const Rectangle3Row = styled.div`
  height: 105px;
  flex-direction: row;
  display: flex;
  margin-right: 5px;
`;

export default TaskNotificationInfo;
