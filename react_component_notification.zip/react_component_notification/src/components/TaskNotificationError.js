import React, { Component } from "react";
import styled, { css } from "styled-components";

function TaskNotificationError(props) {
  return (
    <Root {...props}>
      <Rect6>
        <Rect>
          <Rectangle5Row>
            <Rectangle5></Rectangle5>
            <IconNotifError>
              <svg
                viewBox="-0 -0 4.592399926185608 23.02874962985515"
                style={{
                  width: 7,
                  height: 37,
                  backgroundColor: "transparent",
                  borderColor: "transparent",
                  marginTop: 32,
                  marginLeft: 44
                }}
              >
                <path
                  strokeWidth={0}
                  fill="rgba(242,238,232,1)"
                  fillOpacity={1}
                  strokeOpacity={1}
                  d="M3.91 22.42 C4.37 22.01 4.59 21.46 4.59 20.75 C4.59 20.12 4.37 19.58 3.92 19.14 C3.47 18.70 2.92 18.48 2.28 18.48 C1.64 18.48 1.10 18.70 0.66 19.14 C0.22 19.58 0.00 20.12 0.00 20.75 C0.00 21.47 0.23 22.03 0.69 22.43 C1.15 22.83 1.70 23.03 2.31 23.03 M1.08 15.13 C1.29 15.59 1.67 15.82 2.22 15.82 C2.76 15.82 3.15 15.58 3.38 15.10 C3.61 14.63 3.83 13.05 3.83 13.05 L4.49 5.55 C4.49 5.55 4.59 4.18 4.59 3.51 C4.59 2.38 4.45 1.51 4.15 0.91 C3.86 0.30 3.28 0.00 2.40 0.00 C1.69 0.00 1.10 0.24 0.66 0.71 C0.22 1.18 0.00 1.84 0.00 2.68 C0.00 3.30 0.14 5.74 0.14 5.74 L0.63 13.02 "
                ></path>
              </svg>
            </IconNotifError>
            <ErrorMessageHereRowColumn>
              <ErrorMessageHereRow>
                <ErrorMessageHere>ERROR MESSAGE HERE</ErrorMessageHere>
                <IconRespMenuCloseRespMenu2>
                  <Group32Stack>
                    <Group32>
                      <Clip22Stack>
                        <svg
                          viewBox="-0 -0 14.67353887549998 14.67269887556435"
                          style={{
                            top: 0,
                            left: 0,
                            width: 15,
                            height: 15,
                            backgroundColor: "transparent",
                            position: "absolute",
                            borderColor: "transparent"
                          }}
                        >
                          <path
                            strokeWidth={0}
                            fill="transparent"
                            fillOpacity={1}
                            strokeOpacity={1}
                            d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                          ></path>
                        </svg>
                        <svg
                          viewBox="-0 -0 14.67353887549998 14.67269887556435"
                          style={{
                            top: 0,
                            left: 0,
                            width: 15,
                            height: 15,
                            backgroundColor: "transparent",
                            position: "absolute",
                            borderColor: "transparent"
                          }}
                        >
                          <defs>
                            <mask
                              id="v7cyEM"
                              x={0}
                              y={0}
                              width={14}
                              height={14}
                            >
                              <path
                                d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                                fill="white"
                              />
                            </mask>
                          </defs>
                          <path
                            strokeWidth={0}
                            fill="rgba(242,243,246,1)"
                            fillOpacity={1}
                            strokeOpacity={1}
                            d="M0.25 14.43 C-0.08 14.10 -0.08 13.57 0.25 13.24 L13.24 0.25 C13.57 -0.08 14.10 -0.08 14.43 0.25 C14.76 0.57 14.76 1.11 14.43 1.43 L1.43 14.43 C1.27 14.59 1.05 14.67 0.84 14.67 C0.63 14.67 0.41 14.59 0.25 14.43 Z"
                            mask="url(#v7cyEM)"
                          ></path>
                        </svg>
                      </Clip22Stack>
                    </Group32>
                    <Group62>
                      <Clip52Stack>
                        <svg
                          viewBox="-0 -0 14.6737068754871 14.67269887556435"
                          style={{
                            top: 0,
                            left: 0,
                            width: 15,
                            height: 15,
                            backgroundColor: "transparent",
                            position: "absolute",
                            borderColor: "transparent"
                          }}
                        >
                          <path
                            strokeWidth={0}
                            fill="transparent"
                            fillOpacity={1}
                            strokeOpacity={1}
                            d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                          ></path>
                        </svg>
                        <svg
                          viewBox="-0 -0 14.6737068754871 14.67269887556435"
                          style={{
                            top: 0,
                            left: 0,
                            width: 15,
                            height: 15,
                            backgroundColor: "transparent",
                            position: "absolute",
                            borderColor: "transparent"
                          }}
                        >
                          <defs>
                            <mask
                              id="A9tbus"
                              x={0}
                              y={0}
                              width={14}
                              height={14}
                            >
                              <path
                                d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                                fill="white"
                              />
                            </mask>
                          </defs>
                          <path
                            strokeWidth={0}
                            fill="rgba(242,243,246,1)"
                            fillOpacity={1}
                            strokeOpacity={1}
                            d="M13.24 14.43 L0.25 1.43 C-0.08 1.11 -0.08 0.57 0.25 0.25 C0.57 -0.08 1.11 -0.08 1.43 0.25 L14.43 13.24 C14.76 13.57 14.76 14.10 14.43 14.43 C14.26 14.59 14.05 14.67 13.83 14.67 C13.62 14.67 13.40 14.59 13.24 14.43 Z"
                            mask="url(#A9tbus)"
                          ></path>
                        </svg>
                      </Clip52Stack>
                    </Group62>
                  </Group32Stack>
                </IconRespMenuCloseRespMenu2>
              </ErrorMessageHereRow>
              <DescriptionOfError>
                Description of error in task execution here. this{"\n"}
                notification is displayed 5 seconds, disapears automatically{" "}
                {"\n"}if user doesn’t click on close
              </DescriptionOfError>
            </ErrorMessageHereRowColumn>
          </Rectangle5Row>
        </Rect>
      </Rect6>
    </Root>
  );
}

const Root = styled.div`
  display: flex;
  flex-direction: column;
`;

const Rect6 = styled.div`
  width: 416px;
  height: 106px;
  background-color: rgba(255,255,255,1);
  flex-direction: column;
  display: flex;
`;

const Rect = styled.div`
  width: 416px;
  height: 106px;
  opacity: 1;
  flex-direction: column;
  display: flex;
`;

const Rectangle5 = styled.div`
  width: 16px;
  height: 105px;
  background-color: rgba(250,178,132,1);
  opacity: 1;
`;

const IconNotifError = styled.div`
  width: 97px;
  height: 87px;
  opacity: 1;
  flex-direction: column;
  display: flex;
`;

const ErrorMessageHere = styled.span`
  font-family: Raleway;
  background-color: transparent;
  color: rgba(250,178,132,1);
  opacity: 1;
  font-size: 18px;
  font-weight: 700;
  font-style: normal;
  letter-spacing: 0.45px;
  margin-top: 14px;
`;

const IconRespMenuCloseRespMenu2 = styled.div`
  width: 15px;
  height: 16px;
  opacity: 1;
  flex-direction: column;
  display: flex;
  margin-left: 63px;
`;

const Group32 = styled.div`
  top: 0px;
  left: 0px;
  width: 15px;
  height: 15px;
  position: absolute;
  opacity: 1;
  flex-direction: column;
  display: flex;
`;

const Clip22Stack = styled.div`
  width: 15px;
  height: 15px;
  position: relative;
`;

const Group62 = styled.div`
  top: 0px;
  left: 0px;
  width: 15px;
  height: 15px;
  position: absolute;
  opacity: 1;
  flex-direction: column;
  display: flex;
`;

const Clip52Stack = styled.div`
  width: 15px;
  height: 15px;
  position: relative;
`;

const Group32Stack = styled.div`
  width: 15px;
  height: 15px;
  position: relative;
`;

const ErrorMessageHereRow = styled.div`
  height: 32px;
  flex-direction: row;
  display: flex;
  margin-right: 8px;
`;

const DescriptionOfError = styled.span`
  font-family: Raleway;
  background-color: transparent;
  color: rgba(216,216,216,1);
  opacity: 1;
  font-size: 10px;
  font-weight: 400;
  font-style: normal;
  letter-spacing: 0.25px;
  margin-top: 7px;
  margin-left: 2px;
`;

const ErrorMessageHereRowColumn = styled.div`
  width: 294px;
  flex-direction: column;
  display: flex;
  margin-left: 4px;
  margin-top: 10px;
  margin-bottom: 26px;
`;

const Rectangle5Row = styled.div`
  height: 105px;
  flex-direction: row;
  display: flex;
  margin-right: 5px;
`;

export default TaskNotificationError;
