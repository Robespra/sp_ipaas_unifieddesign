import React, { Component } from "react";
import styled, { css } from "styled-components";

function TaskNotificationSuccess(props) {
  return (
    <Root {...props}>
      <Rect3>
        <Rect2>
          <RectStack>
            <Rect>
              <Rectangle1Row>
                <Rectangle1></Rectangle1>
                <IconNotifSuccess>
                  <svg
                    viewBox="-0 -0 26.00415346191207 22.62837094080568"
                    style={{
                      width: 26,
                      height: 23,
                      backgroundColor: "transparent",
                      borderColor: "transparent",
                      marginTop: 18,
                      marginLeft: 18
                    }}
                  >
                    <path
                      strokeWidth={0}
                      fill="rgba(106,213,202,1)"
                      fillOpacity={1}
                      strokeOpacity={1}
                      d="M9.06 22.63 C8.37 22.63 7.71 22.35 7.23 21.84 L0.70 14.98 C-0.26 13.97 -0.23 12.38 0.78 11.42 C1.79 10.46 3.38 10.50 4.35 11.51 L8.92 16.31 L21.53 0.92 C22.42 -0.15 24.01 -0.31 25.08 0.57 C26.16 1.46 26.31 3.04 25.43 4.12 L11.01 21.71 C10.55 22.27 9.87 22.60 9.15 22.63 C9.12 22.63 9.09 22.63 9.06 22.63 "
                    ></path>
                  </svg>
                </IconNotifSuccess>
                <SuccessMessageHereRowColumn>
                  <SuccessMessageHereRow>
                    <SuccessMessageHere>
                      SUCCESS MESSAGE HERE
                    </SuccessMessageHere>
                    <IconRespMenuCloseRespMenu>
                      <Group3Stack>
                        <Group3>
                          <Clip2Stack>
                            <svg
                              viewBox="-0 -0 14.67353887549998 14.67269887556435"
                              style={{
                                top: 0,
                                left: 0,
                                width: 15,
                                height: 15,
                                backgroundColor: "transparent",
                                position: "absolute",
                                borderColor: "transparent"
                              }}
                            >
                              <path
                                strokeWidth={0}
                                fill="transparent"
                                fillOpacity={1}
                                strokeOpacity={1}
                                d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                              ></path>
                            </svg>
                            <svg
                              viewBox="-0 -0 14.67353887549998 14.67269887556435"
                              style={{
                                top: 0,
                                left: 0,
                                width: 15,
                                height: 15,
                                backgroundColor: "transparent",
                                position: "absolute",
                                borderColor: "transparent"
                              }}
                            >
                              <defs>
                                <mask
                                  id="LH42mR"
                                  x={0}
                                  y={0}
                                  width={14}
                                  height={14}
                                >
                                  <path
                                    d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                                    fill="white"
                                  />
                                </mask>
                              </defs>
                              <path
                                strokeWidth={0}
                                fill="rgba(242,243,246,1)"
                                fillOpacity={1}
                                strokeOpacity={1}
                                d="M0.25 14.43 C-0.08 14.10 -0.08 13.57 0.25 13.24 L13.24 0.25 C13.57 -0.08 14.10 -0.08 14.43 0.25 C14.76 0.57 14.76 1.11 14.43 1.43 L1.43 14.43 C1.27 14.59 1.05 14.67 0.84 14.67 C0.63 14.67 0.41 14.59 0.25 14.43 Z"
                                mask="url(#LH42mR)"
                              ></path>
                            </svg>
                          </Clip2Stack>
                        </Group3>
                        <Group6>
                          <Clip5Stack>
                            <svg
                              viewBox="-0 -0 14.6737068754871 14.67269887556435"
                              style={{
                                top: 0,
                                left: 0,
                                width: 15,
                                height: 15,
                                backgroundColor: "transparent",
                                position: "absolute",
                                borderColor: "transparent"
                              }}
                            >
                              <path
                                strokeWidth={0}
                                fill="transparent"
                                fillOpacity={1}
                                strokeOpacity={1}
                                d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                              ></path>
                            </svg>
                            <svg
                              viewBox="-0 -0 14.6737068754871 14.67269887556435"
                              style={{
                                top: 0,
                                left: 0,
                                width: 15,
                                height: 15,
                                backgroundColor: "transparent",
                                position: "absolute",
                                borderColor: "transparent"
                              }}
                            >
                              <defs>
                                <mask
                                  id="qMsiSB"
                                  x={0}
                                  y={0}
                                  width={14}
                                  height={14}
                                >
                                  <path
                                    d="M0.00 0.00 L14.67 0.00 L14.67 14.67 L0.00 14.67 Z"
                                    fill="white"
                                  />
                                </mask>
                              </defs>
                              <path
                                strokeWidth={0}
                                fill="rgba(242,243,246,1)"
                                fillOpacity={1}
                                strokeOpacity={1}
                                d="M13.24 14.43 L0.25 1.43 C-0.08 1.11 -0.08 0.57 0.25 0.25 C0.57 -0.08 1.11 -0.08 1.43 0.25 L14.43 13.24 C14.76 13.57 14.76 14.10 14.43 14.43 C14.26 14.59 14.05 14.67 13.83 14.67 C13.62 14.67 13.40 14.59 13.24 14.43 Z"
                                mask="url(#qMsiSB)"
                              ></path>
                            </svg>
                          </Clip5Stack>
                        </Group6>
                      </Group3Stack>
                    </IconRespMenuCloseRespMenu>
                  </SuccessMessageHereRow>
                  <DescriptionOfSucce>
                    Description of successfuly excecuted task here. this{"\n"}
                    notification is displayed 5 seconds, disapears automatically{" "}
                    {"\n"}if user doesn’t click on close
                  </DescriptionOfSucce>
                </SuccessMessageHereRowColumn>
              </Rectangle1Row>
            </Rect>
            <Text></Text>
          </RectStack>
        </Rect2>
      </Rect3>
    </Root>
  );
}

const Root = styled.div`
  display: flex;
  flex-direction: column;
`;

const Rect3 = styled.div`
  width: 416px;
  height: 106px;
  background-color: rgba(255,255,255,1);
  flex-direction: column;
  display: flex;
`;

const Rect2 = styled.div`
  width: 416px;
  height: 106px;
  background-color: rgba(255,255,255,1);
  flex-direction: column;
  display: flex;
`;

const Rect = styled.div`
  width: 416px;
  height: 106px;
  position: absolute;
  opacity: 1;
  left: 0px;
  top: 0px;
  flex-direction: column;
  display: flex;
`;

const Rectangle1 = styled.div`
  width: 16px;
  height: 105px;
  background-color: rgba(106,213,202,1);
  opacity: 1;
`;

const IconNotifSuccess = styled.div`
  width: 60px;
  height: 61px;
  opacity: 0.3;
  flex-direction: column;
  display: flex;
  margin-left: 15px;
  margin-top: 23px;
`;

const SuccessMessageHere = styled.span`
  font-family: Raleway;
  background-color: transparent;
  color: rgba(106,213,202,1);
  opacity: 1;
  font-size: 18px;
  font-weight: 700;
  font-style: normal;
  letter-spacing: 0.45px;
  margin-top: 14px;
`;

const IconRespMenuCloseRespMenu = styled.div`
  width: 15px;
  height: 16px;
  opacity: 1;
  flex-direction: column;
  display: flex;
  margin-left: 41px;
`;

const Group3 = styled.div`
  top: 0px;
  left: 0px;
  width: 15px;
  height: 15px;
  position: absolute;
  opacity: 1;
  flex-direction: column;
  display: flex;
`;

const Clip2Stack = styled.div`
  width: 15px;
  height: 15px;
  position: relative;
`;

const Group6 = styled.div`
  top: 0px;
  left: 0px;
  width: 15px;
  height: 15px;
  position: absolute;
  opacity: 1;
  flex-direction: column;
  display: flex;
`;

const Clip5Stack = styled.div`
  width: 15px;
  height: 15px;
  position: relative;
`;

const Group3Stack = styled.div`
  width: 15px;
  height: 15px;
  position: relative;
`;

const SuccessMessageHereRow = styled.div`
  height: 32px;
  flex-direction: row;
  display: flex;
  margin-right: 8px;
`;

const DescriptionOfSucce = styled.span`
  font-family: Raleway;
  background-color: transparent;
  color: rgba(216,216,216,1);
  opacity: 1;
  font-size: 10px;
  font-weight: 400;
  font-style: normal;
  letter-spacing: 0.25px;
  margin-top: 7px;
  margin-left: 2px;
`;

const SuccessMessageHereRowColumn = styled.div`
  width: 294px;
  flex-direction: column;
  display: flex;
  margin-left: 26px;
  margin-top: 10px;
  margin-bottom: 26px;
`;

const Rectangle1Row = styled.div`
  height: 105px;
  flex-direction: row;
  display: flex;
  margin-right: 5px;
`;

const Text = styled.span`
  font-family: Roboto;
  top: 53px;
  left: 208px;
  color: #121212;
  position: absolute;
  font-weight: regular;
  font-style: normal;
`;

const RectStack = styled.div`
  width: 416px;
  height: 106px;
  position: relative;
`;

export default TaskNotificationSuccess;
